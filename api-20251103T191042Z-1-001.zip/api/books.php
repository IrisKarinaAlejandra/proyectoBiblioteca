<?php
// api/books.php (robusto: lista/CRUD + paginación sin placeholders en LIMIT/OFFSET)
require_once __DIR__.'/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// ---------- LIST ----------
if ($method === 'GET' && $action === 'list') {
  require_login();
  try {
    $page  = max(1, intval($_GET['page']  ?? 1));
    $limit = max(1, min(100, intval($_GET['limit'] ?? 200)));
    $offset = ($page - 1) * $limit;

    $q = trim($_GET['q'] ?? '');
    // filtros de año SOLO si vienen presentes y no vacíos
    $hasMin = isset($_GET['minYear']) && $_GET['minYear'] !== '';
    $hasMax = isset($_GET['maxYear']) && $_GET['maxYear'] !== '';
    $minYear = $hasMin ? intval($_GET['minYear']) : null;
    $maxYear = $hasMax ? intval($_GET['maxYear']) : null;

    $where = [];
    $args = [];
    if ($q !== '') {
      $where[] = "(title LIKE ? OR author LIKE ? OR isbn LIKE ?)";
      $like = "%$q%";
      $args[] = $like; $args[] = $like; $args[] = $like;
    }
    if ($hasMin && $hasMax) {
      // Incluye year NULL o 0
      $where[] = "((`year` BETWEEN ? AND ?) OR `year` IS NULL OR `year`=0)";
      $args[] = $minYear; $args[] = $maxYear;
    }

    $sql = "SELECT id, title, author, isbn, `year` AS year, copies FROM books";
    if ($where) $sql .= " WHERE ".implode(" AND ", $where);
    $sql .= " ORDER BY id DESC LIMIT ".$limit." OFFSET ".$offset;

    $stmt = db()->prepare($sql);
    $stmt->execute($args);
    $rows = $stmt->fetchAll();

    echo json_encode(['ok'=>true, 'rows'=>$rows, 'page'=>$page, 'limit'=>$limit]); 
  } catch (Throwable $e) {
    error_log('books list error: '.$e->getMessage());
    http_response_code(500);
    echo json_encode(['ok'=>false, 'error'=>'DB error en listado de libros']);
  }
  exit;
}

// ---------- CREATE ----------
if ($method === 'POST' && $action === 'create') {
  require_login();
  $in = json_input();
  $stmt = db()->prepare("INSERT INTO books (title, author, isbn, `year`, copies) VALUES (?,?,?,?,?)");
  $stmt->execute([trim($in['title']??''), trim($in['author']??''), trim($in['isbn']??''), intval($in['year']??0), intval($in['copies']??1)]);
  echo json_encode(['ok'=>true, 'id'=>db()->lastInsertId()]);
  exit;
}

// ---------- UPDATE ----------
if ($method === 'PUT' && $action === 'update') {
  require_login();
  parse_str($_SERVER['QUERY_STRING'], $qs);
  $id = intval($qs['id'] ?? 0);
  $in = json_input();
  $stmt = db()->prepare("UPDATE books SET title=?,author=?,isbn=?,`year`=?,copies=? WHERE id=?");
  $stmt->execute([trim($in['title']??''), trim($in['author']??''), trim($in['isbn']??''), intval($in['year']??0), intval($in['copies']??1), $id]);
  echo json_encode(['ok'=>true]);
  exit;
}

// ---------- DELETE ----------
if ($method === 'DELETE' && $action === 'delete') {
  require_login();
  $id = intval($_GET['id'] ?? 0);
  $stmt = db()->prepare("DELETE FROM books WHERE id=?");
  $stmt->execute([$id]);
  echo json_encode(['ok'=>true]);
  exit;
}

// ---------- IMPORT CSV ----------
if ($method === 'POST' && $action === 'import_csv') {
  require_login();
  if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['ok'=>false, 'error'=>'Falta archivo CSV']);
    exit;
  }
  $rows = csv_to_rows($_FILES['file']['tmp_name']);
  $ins = db()->prepare("INSERT INTO books (title, author, isbn, `year`, copies) VALUES (?,?,?,?,?)");
  $count = 0;
  foreach ($rows as $r) {
    $ins->execute([trim($r['title']??''), trim($r['author']??''), trim($r['isbn']??''), intval($r['year']??0), intval($r['copies']??1)]);
    $count++;
  }
  echo json_encode(['ok'=>true, 'imported'=>$count]);
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Solicitud no válida']);
