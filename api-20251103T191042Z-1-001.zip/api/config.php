<?php
// api/config.php
// Edita estas constantes con tus datos de Hostinger
define('DB_HOST', 'localhost');
define('DB_NAME', 'u108467150_BIBLIOTECITTJ');
define('DB_USER', 'u108467150_TEC');
define('DB_PASS', 'Administrad123#');
define('FINE_PER_DAY', 5); // MXN por día de retraso
define('ALLOWED_EMAIL_DOMAIN', '@tlajomulco.tecnm.mx'); // dominio institucional

// Opciones CORS (misma raíz normalmente; ajusta si usas dominios distintos)
define('CORS_ALLOW_ORIGIN', '*');
