<?php
// api/history.php
require_once __DIR__.'/db.php';

require_login();
$student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
$book_id = isset($_GET['book_id']) ? intval($_GET['book_id']) : 0;

if ($student_id > 0) {
  $stmt = db()->prepare("
    SELECT l.*, s.name AS student_name, b.title AS book_title
    FROM loans l
    JOIN students s ON s.id = l.student_id
    JOIN books b ON b.id = l.book_id
    WHERE l.student_id = ?
    ORDER BY l.id DESC
  ");
  $stmt->execute([$student_id]);
  echo json_encode(['ok'=>true, 'rows'=>$stmt->fetchAll()]);
  exit;
}

if ($book_id > 0) {
  $stmt = db()->prepare("
    SELECT l.*, s.name AS student_name, b.title AS book_title
    FROM loans l
    JOIN students s ON s.id = l.student_id
    JOIN books b ON b.id = l.book_id
    WHERE l.book_id = ?
    ORDER BY l.id DESC
  ");
  $stmt->execute([$book_id]);
  echo json_encode(['ok'=>true, 'rows'=>$stmt->fetchAll()]);
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Debe indicar student_id o book_id']);
