<?php
// api/reports.php
require_once __DIR__.'/db.php';

$type = $_GET['type'] ?? 'loans';
require_login();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$type.'_report.csv"');

$output = fopen('php://output', 'w');

if ($type === 'inventory') {
  fputcsv($output, ['id','title','author','isbn','year','copies']);
  $stmt = db()->query("SELECT id,title,author,isbn,year,copies FROM books ORDER BY id DESC");
  foreach ($stmt as $row) fputcsv($output, $row);
  exit;
}

if ($type === 'fines') {
  fputcsv($output, ['fine_id','loan_id','student','book','amount','status','created_at','paid_at']);
  $stmt = db()->query("
    SELECT f.id AS fine_id, f.loan_id, s.name AS student, b.title AS book, f.amount, f.status, f.created_at, f.paid_at
    FROM fines f
    JOIN loans l ON l.id = f.loan_id
    JOIN students s ON s.id = l.student_id
    JOIN books b ON b.id = l.book_id
    ORDER BY f.id DESC
  ");
  foreach ($stmt as $row) fputcsv($output, $row);
  exit;
}

// default: loans
fputcsv($output, ['loan_id','student','book','loaned_at','due_date','returned_at','fine_amount']);
$stmt = db()->query("
  SELECT l.id AS loan_id, s.name AS student, b.title AS book, l.loaned_at, l.due_date, l.returned_at, l.fine_amount
  FROM loans l
  JOIN students s ON s.id = l.student_id
  JOIN books b ON b.id = l.book_id
  ORDER BY l.id DESC
");
foreach ($stmt as $row) fputcsv($output, $row);
