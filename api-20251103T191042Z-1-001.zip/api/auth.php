<?php
// api/auth.php
require_once __DIR__.'/db.php';

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

if ($action === 'login') {
  $in = json_input();
  $username = trim($in['username'] ?? '');
  $password = $in['password'] ?? '';

  $stmt = db()->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
  $stmt->execute([$username]);
  $user = $stmt->fetch();

  if ($user && password_verify($password, $user['password_hash'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'] ?? 'admin';
    echo json_encode(['ok'=>true, 'username'=>$user['username'], 'role'=>$user['role'] ?? 'admin']);
  } else {
    http_response_code(401);
    echo json_encode(['ok'=>false, 'error'=>'Credenciales inválidas']);
  }
  exit;
}

if ($action === 'me') {
  if (!empty($_SESSION['user_id'])) {
    echo json_encode(['ok'=>true, 'username'=>$_SESSION['username'], 'role'=>($_SESSION['role'] ?? 'admin')]);
  } else {
    http_response_code(401);
    echo json_encode(['ok'=>false]);
  }
  exit;
}

if ($action === 'logout') {
  session_destroy();
  echo json_encode(['ok'=>true]);
  exit;
}

if ($action === 'seed_admin') {
  // Crea usuario admin si no existe
  $stmt = db()->prepare('SELECT COUNT(*) c FROM users WHERE username = ?');
  $stmt->execute(['admin']);
  $exists = $stmt->fetch()['c'] ?? 0;
  if (!$exists) {
    $hash = password_hash('admin123', PASSWORD_BCRYPT);
    $ins = db()->prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)');
    $ins->execute(['admin', $hash, 'admin']);
    echo json_encode(['ok'=>true, 'message'=>'Usuario admin creado: admin / admin123 (cámbialo después de entrar)']);
  } else {
    echo json_encode(['ok'=>true, 'message'=>'Admin ya existe']);
  }
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Acción no válida']);
