<?php
// api/loans.php
require_once __DIR__.'/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET' && $action === 'list') {
  require_login();
  $stmt = db()->query("
    SELECT l.*, s.name AS student_name, b.title AS book_title
    FROM loans l
    JOIN students s ON s.id = l.student_id
    JOIN books b ON b.id = l.book_id
    ORDER BY l.id DESC LIMIT 200
  ");
  echo json_encode(['ok'=>true, 'rows'=>$stmt->fetchAll()]);
  exit;
}

if ($method === 'POST' && $action === 'create') {
  require_login();
  $in = json_input();
  $student_id = intval($in['student_id'] ?? 0);
  $book_id = intval($in['book_id'] ?? 0);
  $due_date = trim($in['due_date'] ?? '');

  // Verifica disponibilidad de ejemplares
  $c1 = db()->prepare("SELECT copies FROM books WHERE id=?");
  $c1->execute([$book_id]);
  $book = $c1->fetch();
  if (!$book) { http_response_code(422); echo json_encode(['ok'=>false,'error'=>'Libro no encontrado']); exit; }

  $c2 = db()->prepare("SELECT COUNT(*) c FROM loans WHERE book_id=? AND returned_at IS NULL");
  $c2->execute([$book_id]);
  $active = $c2->fetch()['c'] ?? 0;
  if ($active >= $book['copies']) {
    http_response_code(422); echo json_encode(['ok'=>false,'error'=>'Sin ejemplares disponibles']); exit;
  }

  $stmt = db()->prepare("INSERT INTO loans (student_id, book_id, loaned_at, due_date) VALUES (?,?,NOW(),?)");
  $stmt->execute([$student_id, $book_id, $due_date]);
  echo json_encode(['ok'=>true, 'id'=>db()->lastInsertId()]);
  exit;
}

if ($method === 'POST' && $action === 'return') {
  require_login();
  $in = json_input();
  $id = intval($in['loan_id'] ?? 0);

  // Calcula multa
  $s = db()->prepare("SELECT id, due_date FROM loans WHERE id=? AND returned_at IS NULL");
  $s->execute([$id]);
  $loan = $s->fetch();
  if (!$loan) { http_response_code(422); echo json_encode(['ok'=>false,'error'=>'Préstamo no encontrado o ya devuelto']); exit; }

  $today = new DateTime('today');
  $due = new DateTime($loan['due_date']);
  $fine = 0;
  if ($today > $due) {
    $diff = $due->diff($today)->days;
    $fine = $diff * FINE_PER_DAY;
  }

  $u = db()->prepare("UPDATE loans SET returned_at = NOW(), fine_amount = ? WHERE id = ?");
  $u->execute([$fine, $id]);

  if ($fine > 0) {
    $f = db()->prepare("INSERT INTO fines (loan_id, amount, status, created_at) VALUES (?,?, 'pending', NOW())");
    $f->execute([$id, $fine]);
  }

  echo json_encode(['ok'=>true, 'fine'=>$fine]);
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Solicitud no válida']);
