<?php
// api/db.php
require_once __DIR__.'/config.php';
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: '.CORS_ALLOW_ORIGIN);
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);
  exit;
}

function db() {
  static $pdo;
  if (!$pdo) {
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
  }
  return $pdo;
}

function json_input() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function require_login() {
  if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['ok'=>false, 'error'=>'No autenticado']);
    exit;
  }
}

function validate_control_number($num) {
  return preg_match('/^\d{8}$/', $num) === 1;
}

function validate_email_domain($email) {
  $email = strtolower(trim($email));
  return str_ends_with($email, strtolower(ALLOWED_EMAIL_DOMAIN));
}

function csv_to_rows($tmpPath) {
  $rows = [];
  if (($handle = fopen($tmpPath, 'r')) !== false) {
    $header = fgetcsv($handle);
    if ($header === false) { return $rows; }
    while (($data = fgetcsv($handle)) !== false) {
      $rows[] = array_combine($header, $data);
    }
    fclose($handle);
  }
  return $rows;
}
