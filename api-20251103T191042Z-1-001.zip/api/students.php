<?php
// api/students.php
require_once __DIR__.'/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET' && $action === 'list') {
  require_login();
  $q = trim($_GET['q'] ?? '');
  $page = max(1, intval($_GET['page'] ?? 1));
  $limit = max(1, min(100, intval($_GET['limit'] ?? 20)));
  $offset = ($page-1) * $limit;
  if ($q) {
    $stmt = db()->prepare("SELECT * FROM students WHERE control_number LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT ".$limit." OFFSET ".$offset);
    $like = "%$q%";
    $stmt->execute([$like,$like,$like]);
  } else {
    $stmt = db()->query("SELECT * FROM students ORDER BY id DESC LIMIT ".$limit." OFFSET ".$offset);
  }
  echo json_encode(['ok'=>true, 'rows'=>$stmt->fetchAll(), 'page'=>$page, 'limit'=>$limit]);
  exit;
}

if ($method === 'POST' && $action === 'create') {
  require_login();
  $in = json_input();
  $control = trim($in['control_number'] ?? '');
  $email = strtolower(trim($in['email'] ?? ''));
  if (!validate_control_number($control)) {
    http_response_code(422);
    echo json_encode(['ok'=>false, 'error'=>'Número de control inválido (8 dígitos)']);
    exit;
  }
  if (!validate_email_domain($email)) {
    http_response_code(422);
    echo json_encode(['ok'=>false, 'error'=>'Correo debe terminar en '.ALLOWED_EMAIL_DOMAIN]);
    exit;
  }
  $stmt = db()->prepare("INSERT INTO students (control_number, name, email, career) VALUES (?,?,?,?)");
  $stmt->execute([$control, trim($in['name']??''), $email, trim($in['career']??'')]);
  echo json_encode(['ok'=>true, 'id'=>db()->lastInsertId()]);
  exit;
}

if ($method === 'PUT' && $action === 'update') {
  require_login();
  parse_str($_SERVER['QUERY_STRING'], $qs);
  $id = intval($qs['id'] ?? 0);
  $in = json_input();
  $control = trim($in['control_number'] ?? '');
  $email = strtolower(trim($in['email'] ?? ''));
  if (!validate_control_number($control)) {
    http_response_code(422);
    echo json_encode(['ok'=>false, 'error'=>'Número de control inválido (8 dígitos)']);
    exit;
  }
  if (!validate_email_domain($email)) {
    http_response_code(422);
    echo json_encode(['ok'=>false, 'error'=>'Correo debe terminar en '.ALLOWED_EMAIL_DOMAIN]);
    exit;
  }
  $stmt = db()->prepare("UPDATE students SET control_number=?, name=?, email=?, career=? WHERE id=?");
  $stmt->execute([$control, trim($in['name']??''), $email, trim($in['career']??''), $id]);
  echo json_encode(['ok'=>true]);
  exit;
}

if ($method === 'DELETE' && $action === 'delete') {
  require_login();
  $id = intval($_GET['id'] ?? 0);
  $stmt = db()->prepare("DELETE FROM students WHERE id=?");
  $stmt->execute([$id]);
  echo json_encode(['ok'=>true]);
  exit;
}

if ($method === 'POST' && $action === 'import_csv') {
  require_login();
  if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['ok'=>false, 'error'=>'Falta archivo CSV']);
    exit;
  }
  $rows = csv_to_rows($_FILES['file']['tmp_name']);
  $ins = db()->prepare("INSERT INTO students (control_number, name, email, career) VALUES (?,?,?,?)");
  $count = 0;
  foreach ($rows as $r) {
    $control = trim($r['control_number']??'');
    $email = strtolower(trim($r['email']??''));
    if (!validate_control_number($control) || !validate_email_domain($email)) continue;
    $ins->execute([$control, trim($r['name']??''), $email, trim($r['career']??'')]);
    $count++;
  }
  echo json_encode(['ok'=>true, 'imported'=>$count]);
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Solicitud no válida']);
