<?php
// api/fines.php
require_once __DIR__.'/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

if ($method === 'GET' && $action === 'list') {
  require_login();
  $stmt = db()->query("
    SELECT f.*, l.student_id, l.book_id, s.name AS student_name, b.title AS book_title
    FROM fines f
    JOIN loans l ON l.id = f.loan_id
    JOIN students s ON s.id = l.student_id
    JOIN books b ON b.id = l.book_id
    ORDER BY f.id DESC LIMIT 200
  ");
  echo json_encode(['ok'=>true, 'rows'=>$stmt->fetchAll()]);
  exit;
}

if ($method === 'POST' && $action === 'pay') {
  require_login();
  $in = json_input();
  $id = intval($in['fine_id'] ?? 0);
  $stmt = db()->prepare("UPDATE fines SET status='paid', paid_at=NOW() WHERE id=?");
  $stmt->execute([$id]);
  echo json_encode(['ok'=>true]);
  exit;
}

http_response_code(400);
echo json_encode(['ok'=>false, 'error'=>'Solicitud no válida']);
