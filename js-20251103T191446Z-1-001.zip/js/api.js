// public/js/api.js
const api = {
  async request(url, opts={}){
    const res = await fetch(url, { credentials:'include', ...opts });
    const ct = res.headers.get('content-type')||'';
    if(ct.includes('application/json')){
      let data;
      try { data = await res.json(); }
      catch(err){
        const txt = await res.text().catch(()=>'');
        console.error('JSON parse error:', err, 'Body:', txt);
        throw err;
      }
      if(!res.ok) throw data;
      return data;
    }else{
      if(!res.ok){
        const txt = await res.text().catch(()=>'');
        throw new Error('HTTP '+res.status+' '+txt);
      }
      return await res.text();
    }
  },
  get(url){ return this.request(url); },
  post(url, data){
    return this.request(url, {
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify(data)
    });
  },
  put(url, data){
    return this.request(url, {
      method:'PUT',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify(data)
    });
  },
  del(url){ return this.request(url, { method:'DELETE' }); },

  toggleTheme(){
    const html = document.documentElement;
    const v = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', v);
    localStorage.setItem('theme', v);
  },
  cycleBackground(){
    const key = 'bg-index';
    const curr = parseInt(localStorage.getItem(key) || '1', 10);
    const next = curr % 3 + 1;
    document.body.style.backgroundImage = `var(--bg-${next})`;
    localStorage.setItem(key, String(next));
  },
  initTheme(){
    const t = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', t);
    const bgIdx = parseInt(localStorage.getItem('bg-index')||'1',10);
    document.body.style.backgroundImage = `var(--bg-${bgIdx})`;
  }
};
api.initTheme();
