// public/js/app.js
(async function(){
  // Check auth
  let me; try{
    me = await api.get('./api/auth.php?action=me');
  }catch(e){
    location.href = 'index.html';
    return;
  }

  document.getElementById('themeToggle').onclick = () => api.toggleTheme();
  document.getElementById('bgToggle').onclick = () => api.cycleBackground();
  // Role-based UI
  const role = (me && me.role) || 'admin';
  document.body.dataset.role = role;
  if(role !== 'admin'){
    document.querySelectorAll('[data-admin-only]').forEach(el=>el.classList.add('d-none'));
  }

  document.getElementById('logoutBtn').onclick = async () => {
    await api.get('./api/auth.php?action=logout');
    location.href = 'index.html';
  };

  // Tabs
  const tabs = document.querySelectorAll('[data-tab]');
  const views = document.querySelectorAll('.view');
  tabs.forEach(t=>t.addEventListener('click', (e)=>{
    e.preventDefault();
    tabs.forEach(x=>x.classList.remove('active'));
    t.classList.add('active');
    views.forEach(v=>v.classList.add('d-none'));
    document.getElementById('view-'+t.dataset.tab).classList.remove('d-none');
  }));

  // Libros
  const tblLibros = document.getElementById('tblLibros');
  async function loadLibros(q=''){
    const get = (id, fallback='') => {
      const el = document.getElementById(id);
      return (el && typeof el.value !== 'undefined') ? el.value : fallback;
    };
    const minYear = get('minYear', '');
    const maxYear = get('maxYear', '');
    const limit = get('limitLibros', 20);
    const page = get('pageLibros', 1);
    const url = `./api/books.php?action=list&q=${encodeURIComponent(q)}&minYear=${minYear}&maxYear=${maxYear}&limit=${limit}&page=${page}`;
    let res;
    try{
      res = await api.get(url);
    }catch(e){
      console.error('loadLibros error', e);
      res = {rows:[]};
    }
    // replaced above
    const rows = Array.isArray(res.rows) ? res.rows : [];
    tblLibros.innerHTML = rows.map(r=>`
      <tr>
        <td>${r.id}</td><td>${r.title}</td><td>${r.author||''}</td><td>${r.isbn||''}</td><td>${r.year||''}</td><td>${r.copies||1}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary" data-edit="${r.id}">Editar</button>
          <button class="btn btn-sm btn-outline-danger" data-del="${r.id}">Borrar</button>
        </td>
      </tr>
    `).join('');
  }
  await loadLibros();
  document.getElementById('btnBuscarLibros').onclick = ()=> loadLibros(document.getElementById('qLibros').value);
  document.getElementById('csvLibros').onchange = async (e)=>{
    const fd = new FormData();
    fd.append('file', e.target.files[0]);
    await fetch('./api/books.php?action=import_csv', { method:'POST', body: fd, credentials:'include' });
    await loadLibros();
  };
  document.getElementById('btnNuevoLibro').onclick = ()=> openLibroModal();

  // Modal Libro
  const modalLibro = new bootstrap.Modal('#modalLibro');
  const formLibro = document.getElementById('formLibro');
  document.getElementById('btnGuardarLibro').onclick = async ()=>{
    const fd = new FormData(formLibro);
    const data = Object.fromEntries(fd.entries());
    data.year = parseInt(data.year||'0',10);
    data.copies = parseInt(data.copies||'1',10);
    if(data.id){
      await api.put('./api/books.php?action=update&id='+data.id, data);
    } else {
      await api.post('./api/books.php?action=create', data);
    }
    modalLibro.hide();
    await loadLibros();
  };
  tblLibros.addEventListener('click', async (e)=>{
    const id = e.target.dataset.edit;
    const del = e.target.dataset.del;
    if(id){
      // load row values from DOM
      const tr = e.target.closest('tr').children;
      formLibro.id.value = id;
      formLibro.title.value = tr[1].textContent;
      formLibro.author.value = tr[2].textContent;
      formLibro.isbn.value = tr[3].textContent;
      formLibro.year.value = tr[4].textContent;
      formLibro.copies.value = tr[5].textContent;
      modalLibro.show();
    }
    if(del){
      if(confirm('¿Borrar libro?')){
        await api.del('./api/books.php?action=delete&id='+del);
        await loadLibros();
      }
    }
  });
  function openLibroModal(){
    formLibro.reset();
    formLibro.id.value = '';
    modalLibro.show();
  }

  // Estudiantes
  const tblEst = document.getElementById('tblEst');
  async function loadEst(q=''){
    const res = await api.get('./api/students.php?action=list&q='+encodeURIComponent(q));
    tblEst.innerHTML = res.rows.map(r=>`
      <tr>
        <td>${r.id}</td><td>${r.control_number}</td><td>${r.name}</td><td>${r.email}</td><td>${r.career||''}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary" data-estedt="${r.id}">Editar</button>
          <button class="btn btn-sm btn-outline-danger" data-estdel="${r.id}">Borrar</button>
        </td>
      </tr>
    `).join('');
  }
  await loadEst();
  document.getElementById('btnBuscarEst').onclick = ()=> loadEst(document.getElementById('qEst').value);
  document.getElementById('csvEst').onchange = async (e)=>{
    const fd = new FormData();
    fd.append('file', e.target.files[0]);
    await fetch('./api/students.php?action=import_csv', { method:'POST', body: fd, credentials:'include' });
    await loadEst();
  };
  document.getElementById('btnNuevoEst').onclick = ()=> openEstModal();

  const modalEst = new bootstrap.Modal('#modalEst');
  const formEst = document.getElementById('formEst');
  document.getElementById('btnGuardarEst').onclick = async ()=>{
    const fd = new FormData(formEst);
    const data = Object.fromEntries(fd.entries());
    // Simple client validations
    if(!/^\d{8}$/.test(data.control_number)){ alert('Número de control inválido'); return; }
    if(!data.email.endsWith('@tlajomulco.tecnm.mx')){ alert('Correo debe terminar en @tlajomulco.tecnm.mx'); return; }
    if(data.id){
      await api.put('./api/students.php?action=update&id='+data.id, data);
    } else {
      await api.post('./api/students.php?action=create', data);
    }
    modalEst.hide();
    await loadEst();
  };
  tblEst.addEventListener('click', async (e)=>{
    const id = e.target.dataset.estedt;
    const del = e.target.dataset.estdel;
    if(id){
      const tr = e.target.closest('tr').children;
      formEst.id.value = id;
      formEst.control_number.value = tr[1].textContent;
      formEst.name.value = tr[2].textContent;
      formEst.email.value = tr[3].textContent;
      formEst.career.value = tr[4].textContent;
      modalEst.show();
    }
    if(del){
      if(confirm('¿Borrar estudiante?')){
        await api.del('./api/students.php?action=delete&id='+del);
        await loadEst();
      }
    }
  });
  function openEstModal(){
    formEst.reset();
    formEst.id.value = '';
    modalEst.show();
  }

  // Préstamos
  const tblPrestamos = document.getElementById('tblPrestamos');
  const btnNuevoPrestamo = document.getElementById('btnNuevoPrestamo');
  async function loadPrestamos(){
    let res; try{ res = await api.get('./api/loans.php?action=list'); }catch(e){ console.error('loadPrestamos', e); res={rows:[]}; }
    tblPrestamos.innerHTML = res.rows.map(r=>`
      <tr>
        <td>${r.id}</td><td>${r.student_name}</td><td>${r.book_title}</td>
        <td>${r.loaned_at}</td><td>${r.due_date}</td><td>${r.returned_at || ''}</td><td>$${r.fine_amount || 0}</td>
        <td class="text-end">
          ${r.returned_at ? '' : `<button class="btn btn-sm btn-outline-success" data-return="${r.id}">Devolver</button>`}
        </td>
      </tr>
    `).join('');
  }
  await loadPrestamos();

  const modalPrestamo = new bootstrap.Modal('#modalPrestamo');
  if(btnNuevoPrestamo){ btnNuevoPrestamo.onclick = async ()=>{
    await fillSelects();
    document.getElementById('dueDate').valueAsDate = new Date(Date.now() + 7*24*3600*1000);
    modalPrestamo.show();
  }; }
  async function fillSelects(){
    let est, libros;
    try{ est = await api.get('./api/students.php?action=list'); }catch(e){ est={rows:[]}; }
    const selEst = document.getElementById('selEst');
    if(selEst){
      const opts = (est.rows||[]).map(r=>`<option value="${r.id}">${r.control_number} — ${r.name}</option>`);
      selEst.innerHTML = opts.length? opts.join('') : '<option value="">(Sin estudiantes)</option>';
    }
    try{ libros = await api.get('./api/books.php?action=list&limit=100&page=1'); }catch(e){ console.error('books list', e); libros={rows:[]}; }
    const selLibro = document.getElementById('selLibro');
    if(selLibro){
      const opts = (libros.rows||[]).map(r=>`<option value="${r.id}">${r.title}</option>`);
      selLibro.innerHTML = opts.length? opts.join('') : '<option value="">(Sin libros disponibles)</option>';
    }
  }
  const btnCrearPrestamo = document.getElementById('btnCrearPrestamo');
  if(btnCrearPrestamo){ btnCrearPrestamo.onclick = async ()=>{
    const selEst = document.getElementById('selEst');
    const selLibro = document.getElementById('selLibro');
    const due = document.getElementById('dueDate');
    const student_id = selEst ? selEst.value : '';
    const book_id = selLibro ? selLibro.value : '';
    const due_date = due ? due.value : '';
    await api.post('./api/loans.php?action=create', { student_id, book_id, due_date });
    modalPrestamo.hide();
    await loadPrestamos();
  }; }
  tblPrestamos && tblPrestamos.addEventListener('click', async (e)=>{
    const btn = e.target.closest('button[data-return]');
    const id = btn ? btn.getAttribute('data-return') : null;
    if(id){
      await api.post('./api/loans.php?action=return', { loan_id: parseInt(id,10) });
      await loadPrestamos();
      await loadMultas();
    }
  });

  // Multas
  const tblMultas = document.getElementById('tblMultas');
  async function loadMultas(){
    const res = await api.get('./api/fines.php?action=list');
    tblMultas.innerHTML = res.rows.map(r=>`
      <tr>
        <td>${r.id}</td><td>${r.student_name}</td><td>${r.book_title}</td><td>$${r.amount}</td>
        <td>${r.status}</td><td>${r.created_at}</td><td>${r.paid_at||''}</td>
        <td class="text-end">
          ${r.status==='pending' ? `<button class="btn btn-sm btn-outline-success" data-pay="${r.id}">Marcar pagada</button>` : ''}
        </td>
      </tr>
    `).join('');
  }
  await loadMultas();
  tblMultas.addEventListener('click', async (e)=>{
    const id = e.target.dataset.pay;
    if(id){
      await api.post('./api/fines.php?action=pay', { fine_id: parseInt(id,10) });
      await loadMultas();
    }
  });

})();

// Branding settings
const modalSettings = new bootstrap.Modal('#modalSettings');
document.getElementById('btnSettings').onclick = ()=>{
  document.getElementById('inpBrand').value = localStorage.getItem('brandName') || 'BiblioTecITTJ';
  document.getElementById('inpColor').value = localStorage.getItem('brandColor') || '#f7f7f7';
  modalSettings.show();
};
document.getElementById('btnSaveBrand').onclick = ()=>{
  const name = document.getElementById('inpBrand').value || 'BiblioTecITTJ';
  const color = document.getElementById('inpColor').value || '#f7f7f7';
  localStorage.setItem('brandName', name);
  localStorage.setItem('brandColor', color);
  applyBrand();
  modalSettings.hide();
};
function applyBrand(){
  const name = localStorage.getItem('brandName') || 'BiblioTecITTJ';
  const color = localStorage.getItem('brandColor') || '#f7f7f7';
  document.getElementById('brandName').textContent = name;
  document.documentElement.style.setProperty('--brand-primary', color);
}
applyBrand();
